/**
 */
package nosql;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NOSQL Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link nosql.NOSQLModel#getConstellations <em>Constellations</em>}</li>
 * </ul>
 * </p>
 *
 * @see nosql.NosqlPackage#getNOSQLModel()
 * @model
 * @generated
 */
public interface NOSQLModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Constellations</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.Constellation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constellations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constellations</em>' containment reference list.
	 * @see nosql.NosqlPackage#getNOSQLModel_Constellations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Constellation> getConstellations();

} // NOSQLModel
