/**
 */
package nosql.impl;

import java.util.Collection;

import nosql.Dimension;
import nosql.Hierarchie;
import nosql.NosqlPackage;
import nosql.Parameter;
import nosql.Suppl;
import nosql.WeakAttribute;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dimension</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link nosql.impl.DimensionImpl#getName <em>Name</em>}</li>
 *   <li>{@link nosql.impl.DimensionImpl#getHierarchies <em>Hierarchies</em>}</li>
 *   <li>{@link nosql.impl.DimensionImpl#getParameters <em>Parameters</em>}</li>
 *   <li>{@link nosql.impl.DimensionImpl#getWeakattributes <em>Weakattributes</em>}</li>
 *   <li>{@link nosql.impl.DimensionImpl#getSuppls <em>Suppls</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DimensionImpl extends MinimalEObjectImpl.Container implements Dimension {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHierarchies() <em>Hierarchies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHierarchies()
	 * @generated
	 * @ordered
	 */
	protected EList<Hierarchie> hierarchies;

	/**
	 * The cached value of the '{@link #getParameters() <em>Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<Parameter> parameters;

	/**
	 * The cached value of the '{@link #getWeakattributes() <em>Weakattributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeakattributes()
	 * @generated
	 * @ordered
	 */
	protected EList<WeakAttribute> weakattributes;

	/**
	 * The cached value of the '{@link #getSuppls() <em>Suppls</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuppls()
	 * @generated
	 * @ordered
	 */
	protected EList<Suppl> suppls;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DimensionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NosqlPackage.Literals.DIMENSION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NosqlPackage.DIMENSION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hierarchie> getHierarchies() {
		if (hierarchies == null) {
			hierarchies = new EObjectContainmentEList<Hierarchie>(Hierarchie.class, this, NosqlPackage.DIMENSION__HIERARCHIES);
		}
		return hierarchies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Parameter> getParameters() {
		if (parameters == null) {
			parameters = new EObjectContainmentEList<Parameter>(Parameter.class, this, NosqlPackage.DIMENSION__PARAMETERS);
		}
		return parameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WeakAttribute> getWeakattributes() {
		if (weakattributes == null) {
			weakattributes = new EObjectContainmentEList<WeakAttribute>(WeakAttribute.class, this, NosqlPackage.DIMENSION__WEAKATTRIBUTES);
		}
		return weakattributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Suppl> getSuppls() {
		if (suppls == null) {
			suppls = new EObjectContainmentEList<Suppl>(Suppl.class, this, NosqlPackage.DIMENSION__SUPPLS);
		}
		return suppls;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case NosqlPackage.DIMENSION__HIERARCHIES:
				return ((InternalEList<?>)getHierarchies()).basicRemove(otherEnd, msgs);
			case NosqlPackage.DIMENSION__PARAMETERS:
				return ((InternalEList<?>)getParameters()).basicRemove(otherEnd, msgs);
			case NosqlPackage.DIMENSION__WEAKATTRIBUTES:
				return ((InternalEList<?>)getWeakattributes()).basicRemove(otherEnd, msgs);
			case NosqlPackage.DIMENSION__SUPPLS:
				return ((InternalEList<?>)getSuppls()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NosqlPackage.DIMENSION__NAME:
				return getName();
			case NosqlPackage.DIMENSION__HIERARCHIES:
				return getHierarchies();
			case NosqlPackage.DIMENSION__PARAMETERS:
				return getParameters();
			case NosqlPackage.DIMENSION__WEAKATTRIBUTES:
				return getWeakattributes();
			case NosqlPackage.DIMENSION__SUPPLS:
				return getSuppls();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NosqlPackage.DIMENSION__NAME:
				setName((String)newValue);
				return;
			case NosqlPackage.DIMENSION__HIERARCHIES:
				getHierarchies().clear();
				getHierarchies().addAll((Collection<? extends Hierarchie>)newValue);
				return;
			case NosqlPackage.DIMENSION__PARAMETERS:
				getParameters().clear();
				getParameters().addAll((Collection<? extends Parameter>)newValue);
				return;
			case NosqlPackage.DIMENSION__WEAKATTRIBUTES:
				getWeakattributes().clear();
				getWeakattributes().addAll((Collection<? extends WeakAttribute>)newValue);
				return;
			case NosqlPackage.DIMENSION__SUPPLS:
				getSuppls().clear();
				getSuppls().addAll((Collection<? extends Suppl>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NosqlPackage.DIMENSION__NAME:
				setName(NAME_EDEFAULT);
				return;
			case NosqlPackage.DIMENSION__HIERARCHIES:
				getHierarchies().clear();
				return;
			case NosqlPackage.DIMENSION__PARAMETERS:
				getParameters().clear();
				return;
			case NosqlPackage.DIMENSION__WEAKATTRIBUTES:
				getWeakattributes().clear();
				return;
			case NosqlPackage.DIMENSION__SUPPLS:
				getSuppls().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NosqlPackage.DIMENSION__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case NosqlPackage.DIMENSION__HIERARCHIES:
				return hierarchies != null && !hierarchies.isEmpty();
			case NosqlPackage.DIMENSION__PARAMETERS:
				return parameters != null && !parameters.isEmpty();
			case NosqlPackage.DIMENSION__WEAKATTRIBUTES:
				return weakattributes != null && !weakattributes.isEmpty();
			case NosqlPackage.DIMENSION__SUPPLS:
				return suppls != null && !suppls.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DimensionImpl
