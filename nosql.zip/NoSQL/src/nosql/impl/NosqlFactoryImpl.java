/**
 */
package nosql.impl;

import nosql.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NosqlFactoryImpl extends EFactoryImpl implements NosqlFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static NosqlFactory init() {
		try {
			NosqlFactory theNosqlFactory = (NosqlFactory)EPackage.Registry.INSTANCE.getEFactory(NosqlPackage.eNS_URI);
			if (theNosqlFactory != null) {
				return theNosqlFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new NosqlFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NosqlFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case NosqlPackage.SUPPL: return createSuppl();
			case NosqlPackage.WEAK_ATTRIBUTE: return createWeakAttribute();
			case NosqlPackage.PARAMETER: return createParameter();
			case NosqlPackage.CONSTELLATION: return createConstellation();
			case NosqlPackage.MESURE: return createMesure();
			case NosqlPackage.HIERARCHIE: return createHierarchie();
			case NosqlPackage.DIMENSION: return createDimension();
			case NosqlPackage.FAIT: return createFait();
			case NosqlPackage.NOSQL_MODEL: return createNOSQLModel();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Suppl createSuppl() {
		SupplImpl suppl = new SupplImpl();
		return suppl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeakAttribute createWeakAttribute() {
		WeakAttributeImpl weakAttribute = new WeakAttributeImpl();
		return weakAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter createParameter() {
		ParameterImpl parameter = new ParameterImpl();
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Constellation createConstellation() {
		ConstellationImpl constellation = new ConstellationImpl();
		return constellation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mesure createMesure() {
		MesureImpl mesure = new MesureImpl();
		return mesure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hierarchie createHierarchie() {
		HierarchieImpl hierarchie = new HierarchieImpl();
		return hierarchie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dimension createDimension() {
		DimensionImpl dimension = new DimensionImpl();
		return dimension;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fait createFait() {
		FaitImpl fait = new FaitImpl();
		return fait;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NOSQLModel createNOSQLModel() {
		NOSQLModelImpl nosqlModel = new NOSQLModelImpl();
		return nosqlModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NosqlPackage getNosqlPackage() {
		return (NosqlPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static NosqlPackage getPackage() {
		return NosqlPackage.eINSTANCE;
	}

} //NosqlFactoryImpl
