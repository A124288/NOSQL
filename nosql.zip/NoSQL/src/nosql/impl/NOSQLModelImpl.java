/**
 */
package nosql.impl;

import java.util.Collection;

import nosql.Constellation;
import nosql.NOSQLModel;
import nosql.NosqlPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>NOSQL Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link nosql.impl.NOSQLModelImpl#getConstellations <em>Constellations</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NOSQLModelImpl extends MinimalEObjectImpl.Container implements NOSQLModel {
	/**
	 * The cached value of the '{@link #getConstellations() <em>Constellations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConstellations()
	 * @generated
	 * @ordered
	 */
	protected EList<Constellation> constellations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NOSQLModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NosqlPackage.Literals.NOSQL_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Constellation> getConstellations() {
		if (constellations == null) {
			constellations = new EObjectContainmentEList<Constellation>(Constellation.class, this, NosqlPackage.NOSQL_MODEL__CONSTELLATIONS);
		}
		return constellations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case NosqlPackage.NOSQL_MODEL__CONSTELLATIONS:
				return ((InternalEList<?>)getConstellations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NosqlPackage.NOSQL_MODEL__CONSTELLATIONS:
				return getConstellations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NosqlPackage.NOSQL_MODEL__CONSTELLATIONS:
				getConstellations().clear();
				getConstellations().addAll((Collection<? extends Constellation>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NosqlPackage.NOSQL_MODEL__CONSTELLATIONS:
				getConstellations().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NosqlPackage.NOSQL_MODEL__CONSTELLATIONS:
				return constellations != null && !constellations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //NOSQLModelImpl
