/**
 */
package nosql.impl;

import java.util.Collection;

import nosql.NosqlPackage;
import nosql.Parameter;
import nosql.Suppl;
import nosql.WeakAttribute;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Suppl</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link nosql.impl.SupplImpl#getName <em>Name</em>}</li>
 *   <li>{@link nosql.impl.SupplImpl#getSuppl_weak_attributes <em>Suppl weak attributes</em>}</li>
 *   <li>{@link nosql.impl.SupplImpl#getSuppl_parameter <em>Suppl parameter</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SupplImpl extends MinimalEObjectImpl.Container implements Suppl {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSuppl_weak_attributes() <em>Suppl weak attributes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuppl_weak_attributes()
	 * @generated
	 * @ordered
	 */
	protected EList<WeakAttribute> suppl_weak_attributes;

	/**
	 * The cached value of the '{@link #getSuppl_parameter() <em>Suppl parameter</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuppl_parameter()
	 * @generated
	 * @ordered
	 */
	protected Parameter suppl_parameter;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SupplImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NosqlPackage.Literals.SUPPL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NosqlPackage.SUPPL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WeakAttribute> getSuppl_weak_attributes() {
		if (suppl_weak_attributes == null) {
			suppl_weak_attributes = new EObjectResolvingEList<WeakAttribute>(WeakAttribute.class, this, NosqlPackage.SUPPL__SUPPL_WEAK_ATTRIBUTES);
		}
		return suppl_weak_attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter getSuppl_parameter() {
		if (suppl_parameter != null && suppl_parameter.eIsProxy()) {
			InternalEObject oldSuppl_parameter = (InternalEObject)suppl_parameter;
			suppl_parameter = (Parameter)eResolveProxy(oldSuppl_parameter);
			if (suppl_parameter != oldSuppl_parameter) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, NosqlPackage.SUPPL__SUPPL_PARAMETER, oldSuppl_parameter, suppl_parameter));
			}
		}
		return suppl_parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter basicGetSuppl_parameter() {
		return suppl_parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSuppl_parameter(Parameter newSuppl_parameter) {
		Parameter oldSuppl_parameter = suppl_parameter;
		suppl_parameter = newSuppl_parameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NosqlPackage.SUPPL__SUPPL_PARAMETER, oldSuppl_parameter, suppl_parameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NosqlPackage.SUPPL__NAME:
				return getName();
			case NosqlPackage.SUPPL__SUPPL_WEAK_ATTRIBUTES:
				return getSuppl_weak_attributes();
			case NosqlPackage.SUPPL__SUPPL_PARAMETER:
				if (resolve) return getSuppl_parameter();
				return basicGetSuppl_parameter();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NosqlPackage.SUPPL__NAME:
				setName((String)newValue);
				return;
			case NosqlPackage.SUPPL__SUPPL_WEAK_ATTRIBUTES:
				getSuppl_weak_attributes().clear();
				getSuppl_weak_attributes().addAll((Collection<? extends WeakAttribute>)newValue);
				return;
			case NosqlPackage.SUPPL__SUPPL_PARAMETER:
				setSuppl_parameter((Parameter)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NosqlPackage.SUPPL__NAME:
				setName(NAME_EDEFAULT);
				return;
			case NosqlPackage.SUPPL__SUPPL_WEAK_ATTRIBUTES:
				getSuppl_weak_attributes().clear();
				return;
			case NosqlPackage.SUPPL__SUPPL_PARAMETER:
				setSuppl_parameter((Parameter)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NosqlPackage.SUPPL__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case NosqlPackage.SUPPL__SUPPL_WEAK_ATTRIBUTES:
				return suppl_weak_attributes != null && !suppl_weak_attributes.isEmpty();
			case NosqlPackage.SUPPL__SUPPL_PARAMETER:
				return suppl_parameter != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //SupplImpl
