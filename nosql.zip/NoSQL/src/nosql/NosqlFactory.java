/**
 */
package nosql;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see nosql.NosqlPackage
 * @generated
 */
public interface NosqlFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NosqlFactory eINSTANCE = nosql.impl.NosqlFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Suppl</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Suppl</em>'.
	 * @generated
	 */
	Suppl createSuppl();

	/**
	 * Returns a new object of class '<em>Weak Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Weak Attribute</em>'.
	 * @generated
	 */
	WeakAttribute createWeakAttribute();

	/**
	 * Returns a new object of class '<em>Parameter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Parameter</em>'.
	 * @generated
	 */
	Parameter createParameter();

	/**
	 * Returns a new object of class '<em>Constellation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Constellation</em>'.
	 * @generated
	 */
	Constellation createConstellation();

	/**
	 * Returns a new object of class '<em>Mesure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mesure</em>'.
	 * @generated
	 */
	Mesure createMesure();

	/**
	 * Returns a new object of class '<em>Hierarchie</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hierarchie</em>'.
	 * @generated
	 */
	Hierarchie createHierarchie();

	/**
	 * Returns a new object of class '<em>Dimension</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dimension</em>'.
	 * @generated
	 */
	Dimension createDimension();

	/**
	 * Returns a new object of class '<em>Fait</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fait</em>'.
	 * @generated
	 */
	Fait createFait();

	/**
	 * Returns a new object of class '<em>NOSQL Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>NOSQL Model</em>'.
	 * @generated
	 */
	NOSQLModel createNOSQLModel();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	NosqlPackage getNosqlPackage();

} //NosqlFactory
