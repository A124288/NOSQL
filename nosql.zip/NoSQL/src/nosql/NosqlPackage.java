/**
 */
package nosql;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see nosql.NosqlFactory
 * @model kind="package"
 * @generated
 */
public interface NosqlPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "nosql";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://nosqlmodel/1.0";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "nosql";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NosqlPackage eINSTANCE = nosql.impl.NosqlPackageImpl.init();

	/**
	 * The meta object id for the '{@link nosql.impl.SupplImpl <em>Suppl</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.SupplImpl
	 * @see nosql.impl.NosqlPackageImpl#getSuppl()
	 * @generated
	 */
	int SUPPL = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Suppl weak attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPL__SUPPL_WEAK_ATTRIBUTES = 1;

	/**
	 * The feature id for the '<em><b>Suppl parameter</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPL__SUPPL_PARAMETER = 2;

	/**
	 * The number of structural features of the '<em>Suppl</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Suppl</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.WeakAttributeImpl <em>Weak Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.WeakAttributeImpl
	 * @see nosql.impl.NosqlPackageImpl#getWeakAttribute()
	 * @generated
	 */
	int WEAK_ATTRIBUTE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEAK_ATTRIBUTE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Weak Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEAK_ATTRIBUTE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Weak Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEAK_ATTRIBUTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.ParameterImpl <em>Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.ParameterImpl
	 * @see nosql.impl.NosqlPackageImpl#getParameter()
	 * @generated
	 */
	int PARAMETER = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NAME = 0;

	/**
	 * The number of structural features of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.ConstellationImpl <em>Constellation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.ConstellationImpl
	 * @see nosql.impl.NosqlPackageImpl#getConstellation()
	 * @generated
	 */
	int CONSTELLATION = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTELLATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Faits</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTELLATION__FAITS = 1;

	/**
	 * The feature id for the '<em><b>Dimensions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTELLATION__DIMENSIONS = 2;

	/**
	 * The number of structural features of the '<em>Constellation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTELLATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Constellation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTELLATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.MesureImpl <em>Mesure</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.MesureImpl
	 * @see nosql.impl.NosqlPackageImpl#getMesure()
	 * @generated
	 */
	int MESURE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESURE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESURE__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Mesure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESURE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Mesure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESURE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.HierarchieImpl <em>Hierarchie</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.HierarchieImpl
	 * @see nosql.impl.NosqlPackageImpl#getHierarchie()
	 * @generated
	 */
	int HIERARCHIE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIERARCHIE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Path</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIERARCHIE__PATH = 1;

	/**
	 * The number of structural features of the '<em>Hierarchie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIERARCHIE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Hierarchie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIERARCHIE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.DimensionImpl <em>Dimension</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.DimensionImpl
	 * @see nosql.impl.NosqlPackageImpl#getDimension()
	 * @generated
	 */
	int DIMENSION = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Hierarchies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__HIERARCHIES = 1;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__PARAMETERS = 2;

	/**
	 * The feature id for the '<em><b>Weakattributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__WEAKATTRIBUTES = 3;

	/**
	 * The feature id for the '<em><b>Suppls</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION__SUPPLS = 4;

	/**
	 * The number of structural features of the '<em>Dimension</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Dimension</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIMENSION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.FaitImpl <em>Fait</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.FaitImpl
	 * @see nosql.impl.NosqlPackageImpl#getFait()
	 * @generated
	 */
	int FAIT = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAIT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Mesures</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAIT__MESURES = 1;

	/**
	 * The feature id for the '<em><b>Stars</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAIT__STARS = 2;

	/**
	 * The number of structural features of the '<em>Fait</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAIT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Fait</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAIT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link nosql.impl.NOSQLModelImpl <em>NOSQL Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see nosql.impl.NOSQLModelImpl
	 * @see nosql.impl.NosqlPackageImpl#getNOSQLModel()
	 * @generated
	 */
	int NOSQL_MODEL = 8;

	/**
	 * The feature id for the '<em><b>Constellations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOSQL_MODEL__CONSTELLATIONS = 0;

	/**
	 * The number of structural features of the '<em>NOSQL Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOSQL_MODEL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>NOSQL Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOSQL_MODEL_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link nosql.Suppl <em>Suppl</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Suppl</em>'.
	 * @see nosql.Suppl
	 * @generated
	 */
	EClass getSuppl();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Suppl#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Suppl#getName()
	 * @see #getSuppl()
	 * @generated
	 */
	EAttribute getSuppl_Name();

	/**
	 * Returns the meta object for the reference list '{@link nosql.Suppl#getSuppl_weak_attributes <em>Suppl weak attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Suppl weak attributes</em>'.
	 * @see nosql.Suppl#getSuppl_weak_attributes()
	 * @see #getSuppl()
	 * @generated
	 */
	EReference getSuppl_Suppl_weak_attributes();

	/**
	 * Returns the meta object for the reference '{@link nosql.Suppl#getSuppl_parameter <em>Suppl parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Suppl parameter</em>'.
	 * @see nosql.Suppl#getSuppl_parameter()
	 * @see #getSuppl()
	 * @generated
	 */
	EReference getSuppl_Suppl_parameter();

	/**
	 * Returns the meta object for class '{@link nosql.WeakAttribute <em>Weak Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Weak Attribute</em>'.
	 * @see nosql.WeakAttribute
	 * @generated
	 */
	EClass getWeakAttribute();

	/**
	 * Returns the meta object for the attribute '{@link nosql.WeakAttribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.WeakAttribute#getName()
	 * @see #getWeakAttribute()
	 * @generated
	 */
	EAttribute getWeakAttribute_Name();

	/**
	 * Returns the meta object for class '{@link nosql.Parameter <em>Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parameter</em>'.
	 * @see nosql.Parameter
	 * @generated
	 */
	EClass getParameter();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Parameter#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Parameter#getName()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_Name();

	/**
	 * Returns the meta object for class '{@link nosql.Constellation <em>Constellation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Constellation</em>'.
	 * @see nosql.Constellation
	 * @generated
	 */
	EClass getConstellation();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Constellation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Constellation#getName()
	 * @see #getConstellation()
	 * @generated
	 */
	EAttribute getConstellation_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Constellation#getFaits <em>Faits</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Faits</em>'.
	 * @see nosql.Constellation#getFaits()
	 * @see #getConstellation()
	 * @generated
	 */
	EReference getConstellation_Faits();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Constellation#getDimensions <em>Dimensions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dimensions</em>'.
	 * @see nosql.Constellation#getDimensions()
	 * @see #getConstellation()
	 * @generated
	 */
	EReference getConstellation_Dimensions();

	/**
	 * Returns the meta object for class '{@link nosql.Mesure <em>Mesure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mesure</em>'.
	 * @see nosql.Mesure
	 * @generated
	 */
	EClass getMesure();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Mesure#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Mesure#getName()
	 * @see #getMesure()
	 * @generated
	 */
	EAttribute getMesure_Name();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Mesure#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see nosql.Mesure#getValue()
	 * @see #getMesure()
	 * @generated
	 */
	EAttribute getMesure_Value();

	/**
	 * Returns the meta object for class '{@link nosql.Hierarchie <em>Hierarchie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hierarchie</em>'.
	 * @see nosql.Hierarchie
	 * @generated
	 */
	EClass getHierarchie();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Hierarchie#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Hierarchie#getName()
	 * @see #getHierarchie()
	 * @generated
	 */
	EAttribute getHierarchie_Name();

	/**
	 * Returns the meta object for the reference list '{@link nosql.Hierarchie#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Path</em>'.
	 * @see nosql.Hierarchie#getPath()
	 * @see #getHierarchie()
	 * @generated
	 */
	EReference getHierarchie_Path();

	/**
	 * Returns the meta object for class '{@link nosql.Dimension <em>Dimension</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dimension</em>'.
	 * @see nosql.Dimension
	 * @generated
	 */
	EClass getDimension();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Dimension#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Dimension#getName()
	 * @see #getDimension()
	 * @generated
	 */
	EAttribute getDimension_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Dimension#getHierarchies <em>Hierarchies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Hierarchies</em>'.
	 * @see nosql.Dimension#getHierarchies()
	 * @see #getDimension()
	 * @generated
	 */
	EReference getDimension_Hierarchies();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Dimension#getParameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameters</em>'.
	 * @see nosql.Dimension#getParameters()
	 * @see #getDimension()
	 * @generated
	 */
	EReference getDimension_Parameters();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Dimension#getWeakattributes <em>Weakattributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Weakattributes</em>'.
	 * @see nosql.Dimension#getWeakattributes()
	 * @see #getDimension()
	 * @generated
	 */
	EReference getDimension_Weakattributes();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Dimension#getSuppls <em>Suppls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Suppls</em>'.
	 * @see nosql.Dimension#getSuppls()
	 * @see #getDimension()
	 * @generated
	 */
	EReference getDimension_Suppls();

	/**
	 * Returns the meta object for class '{@link nosql.Fait <em>Fait</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fait</em>'.
	 * @see nosql.Fait
	 * @generated
	 */
	EClass getFait();

	/**
	 * Returns the meta object for the attribute '{@link nosql.Fait#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see nosql.Fait#getName()
	 * @see #getFait()
	 * @generated
	 */
	EAttribute getFait_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.Fait#getMesures <em>Mesures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mesures</em>'.
	 * @see nosql.Fait#getMesures()
	 * @see #getFait()
	 * @generated
	 */
	EReference getFait_Mesures();

	/**
	 * Returns the meta object for the reference list '{@link nosql.Fait#getStars <em>Stars</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Stars</em>'.
	 * @see nosql.Fait#getStars()
	 * @see #getFait()
	 * @generated
	 */
	EReference getFait_Stars();

	/**
	 * Returns the meta object for class '{@link nosql.NOSQLModel <em>NOSQL Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>NOSQL Model</em>'.
	 * @see nosql.NOSQLModel
	 * @generated
	 */
	EClass getNOSQLModel();

	/**
	 * Returns the meta object for the containment reference list '{@link nosql.NOSQLModel#getConstellations <em>Constellations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Constellations</em>'.
	 * @see nosql.NOSQLModel#getConstellations()
	 * @see #getNOSQLModel()
	 * @generated
	 */
	EReference getNOSQLModel_Constellations();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NosqlFactory getNosqlFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link nosql.impl.SupplImpl <em>Suppl</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.SupplImpl
		 * @see nosql.impl.NosqlPackageImpl#getSuppl()
		 * @generated
		 */
		EClass SUPPL = eINSTANCE.getSuppl();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPPL__NAME = eINSTANCE.getSuppl_Name();

		/**
		 * The meta object literal for the '<em><b>Suppl weak attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPPL__SUPPL_WEAK_ATTRIBUTES = eINSTANCE.getSuppl_Suppl_weak_attributes();

		/**
		 * The meta object literal for the '<em><b>Suppl parameter</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPPL__SUPPL_PARAMETER = eINSTANCE.getSuppl_Suppl_parameter();

		/**
		 * The meta object literal for the '{@link nosql.impl.WeakAttributeImpl <em>Weak Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.WeakAttributeImpl
		 * @see nosql.impl.NosqlPackageImpl#getWeakAttribute()
		 * @generated
		 */
		EClass WEAK_ATTRIBUTE = eINSTANCE.getWeakAttribute();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEAK_ATTRIBUTE__NAME = eINSTANCE.getWeakAttribute_Name();

		/**
		 * The meta object literal for the '{@link nosql.impl.ParameterImpl <em>Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.ParameterImpl
		 * @see nosql.impl.NosqlPackageImpl#getParameter()
		 * @generated
		 */
		EClass PARAMETER = eINSTANCE.getParameter();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__NAME = eINSTANCE.getParameter_Name();

		/**
		 * The meta object literal for the '{@link nosql.impl.ConstellationImpl <em>Constellation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.ConstellationImpl
		 * @see nosql.impl.NosqlPackageImpl#getConstellation()
		 * @generated
		 */
		EClass CONSTELLATION = eINSTANCE.getConstellation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSTELLATION__NAME = eINSTANCE.getConstellation_Name();

		/**
		 * The meta object literal for the '<em><b>Faits</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTELLATION__FAITS = eINSTANCE.getConstellation_Faits();

		/**
		 * The meta object literal for the '<em><b>Dimensions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTELLATION__DIMENSIONS = eINSTANCE.getConstellation_Dimensions();

		/**
		 * The meta object literal for the '{@link nosql.impl.MesureImpl <em>Mesure</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.MesureImpl
		 * @see nosql.impl.NosqlPackageImpl#getMesure()
		 * @generated
		 */
		EClass MESURE = eINSTANCE.getMesure();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESURE__NAME = eINSTANCE.getMesure_Name();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESURE__VALUE = eINSTANCE.getMesure_Value();

		/**
		 * The meta object literal for the '{@link nosql.impl.HierarchieImpl <em>Hierarchie</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.HierarchieImpl
		 * @see nosql.impl.NosqlPackageImpl#getHierarchie()
		 * @generated
		 */
		EClass HIERARCHIE = eINSTANCE.getHierarchie();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HIERARCHIE__NAME = eINSTANCE.getHierarchie_Name();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HIERARCHIE__PATH = eINSTANCE.getHierarchie_Path();

		/**
		 * The meta object literal for the '{@link nosql.impl.DimensionImpl <em>Dimension</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.DimensionImpl
		 * @see nosql.impl.NosqlPackageImpl#getDimension()
		 * @generated
		 */
		EClass DIMENSION = eINSTANCE.getDimension();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIMENSION__NAME = eINSTANCE.getDimension_Name();

		/**
		 * The meta object literal for the '<em><b>Hierarchies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIMENSION__HIERARCHIES = eINSTANCE.getDimension_Hierarchies();

		/**
		 * The meta object literal for the '<em><b>Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIMENSION__PARAMETERS = eINSTANCE.getDimension_Parameters();

		/**
		 * The meta object literal for the '<em><b>Weakattributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIMENSION__WEAKATTRIBUTES = eINSTANCE.getDimension_Weakattributes();

		/**
		 * The meta object literal for the '<em><b>Suppls</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIMENSION__SUPPLS = eINSTANCE.getDimension_Suppls();

		/**
		 * The meta object literal for the '{@link nosql.impl.FaitImpl <em>Fait</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.FaitImpl
		 * @see nosql.impl.NosqlPackageImpl#getFait()
		 * @generated
		 */
		EClass FAIT = eINSTANCE.getFait();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FAIT__NAME = eINSTANCE.getFait_Name();

		/**
		 * The meta object literal for the '<em><b>Mesures</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FAIT__MESURES = eINSTANCE.getFait_Mesures();

		/**
		 * The meta object literal for the '<em><b>Stars</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FAIT__STARS = eINSTANCE.getFait_Stars();

		/**
		 * The meta object literal for the '{@link nosql.impl.NOSQLModelImpl <em>NOSQL Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see nosql.impl.NOSQLModelImpl
		 * @see nosql.impl.NosqlPackageImpl#getNOSQLModel()
		 * @generated
		 */
		EClass NOSQL_MODEL = eINSTANCE.getNOSQLModel();

		/**
		 * The meta object literal for the '<em><b>Constellations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NOSQL_MODEL__CONSTELLATIONS = eINSTANCE.getNOSQLModel_Constellations();

	}

} //NosqlPackage
