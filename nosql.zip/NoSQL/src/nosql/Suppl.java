/**
 */
package nosql;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Suppl</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link nosql.Suppl#getName <em>Name</em>}</li>
 *   <li>{@link nosql.Suppl#getSuppl_weak_attributes <em>Suppl weak attributes</em>}</li>
 *   <li>{@link nosql.Suppl#getSuppl_parameter <em>Suppl parameter</em>}</li>
 * </ul>
 * </p>
 *
 * @see nosql.NosqlPackage#getSuppl()
 * @model
 * @generated
 */
public interface Suppl extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see nosql.NosqlPackage#getSuppl_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link nosql.Suppl#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Suppl weak attributes</b></em>' reference list.
	 * The list contents are of type {@link nosql.WeakAttribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Suppl weak attributes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Suppl weak attributes</em>' reference list.
	 * @see nosql.NosqlPackage#getSuppl_Suppl_weak_attributes()
	 * @model
	 * @generated
	 */
	EList<WeakAttribute> getSuppl_weak_attributes();

	/**
	 * Returns the value of the '<em><b>Suppl parameter</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Suppl parameter</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Suppl parameter</em>' reference.
	 * @see #setSuppl_parameter(Parameter)
	 * @see nosql.NosqlPackage#getSuppl_Suppl_parameter()
	 * @model required="true"
	 * @generated
	 */
	Parameter getSuppl_parameter();

	/**
	 * Sets the value of the '{@link nosql.Suppl#getSuppl_parameter <em>Suppl parameter</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Suppl parameter</em>' reference.
	 * @see #getSuppl_parameter()
	 * @generated
	 */
	void setSuppl_parameter(Parameter value);

} // Suppl
