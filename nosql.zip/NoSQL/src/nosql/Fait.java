/**
 */
package nosql;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fait</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link nosql.Fait#getName <em>Name</em>}</li>
 *   <li>{@link nosql.Fait#getMesures <em>Mesures</em>}</li>
 *   <li>{@link nosql.Fait#getStars <em>Stars</em>}</li>
 * </ul>
 * </p>
 *
 * @see nosql.NosqlPackage#getFait()
 * @model
 * @generated
 */
public interface Fait extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see nosql.NosqlPackage#getFait_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link nosql.Fait#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Mesures</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.Mesure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mesures</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mesures</em>' containment reference list.
	 * @see nosql.NosqlPackage#getFait_Mesures()
	 * @model containment="true"
	 * @generated
	 */
	EList<Mesure> getMesures();

	/**
	 * Returns the value of the '<em><b>Stars</b></em>' reference list.
	 * The list contents are of type {@link nosql.Dimension}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stars</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stars</em>' reference list.
	 * @see nosql.NosqlPackage#getFait_Stars()
	 * @model
	 * @generated
	 */
	EList<Dimension> getStars();

} // Fait
