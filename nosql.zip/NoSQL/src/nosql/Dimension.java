/**
 */
package nosql;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dimension</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link nosql.Dimension#getName <em>Name</em>}</li>
 *   <li>{@link nosql.Dimension#getHierarchies <em>Hierarchies</em>}</li>
 *   <li>{@link nosql.Dimension#getParameters <em>Parameters</em>}</li>
 *   <li>{@link nosql.Dimension#getWeakattributes <em>Weakattributes</em>}</li>
 *   <li>{@link nosql.Dimension#getSuppls <em>Suppls</em>}</li>
 * </ul>
 * </p>
 *
 * @see nosql.NosqlPackage#getDimension()
 * @model
 * @generated
 */
public interface Dimension extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see nosql.NosqlPackage#getDimension_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link nosql.Dimension#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Hierarchies</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.Hierarchie}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hierarchies</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hierarchies</em>' containment reference list.
	 * @see nosql.NosqlPackage#getDimension_Hierarchies()
	 * @model containment="true"
	 * @generated
	 */
	EList<Hierarchie> getHierarchies();

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.Parameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see nosql.NosqlPackage#getDimension_Parameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<Parameter> getParameters();

	/**
	 * Returns the value of the '<em><b>Weakattributes</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.WeakAttribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Weakattributes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weakattributes</em>' containment reference list.
	 * @see nosql.NosqlPackage#getDimension_Weakattributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<WeakAttribute> getWeakattributes();

	/**
	 * Returns the value of the '<em><b>Suppls</b></em>' containment reference list.
	 * The list contents are of type {@link nosql.Suppl}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Suppls</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Suppls</em>' containment reference list.
	 * @see nosql.NosqlPackage#getDimension_Suppls()
	 * @model containment="true"
	 * @generated
	 */
	EList<Suppl> getSuppls();

} // Dimension
