/**
 */
package nosql.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import nosql.Constellation;
import nosql.NosqlFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Constellation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConstellationTest extends TestCase {

	/**
	 * The fixture for this Constellation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Constellation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ConstellationTest.class);
	}

	/**
	 * Constructs a new Constellation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConstellationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Constellation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Constellation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Constellation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Constellation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(NosqlFactory.eINSTANCE.createConstellation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ConstellationTest
