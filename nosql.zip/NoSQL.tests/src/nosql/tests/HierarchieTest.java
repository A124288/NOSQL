/**
 */
package nosql.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import nosql.Hierarchie;
import nosql.NosqlFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Hierarchie</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class HierarchieTest extends TestCase {

	/**
	 * The fixture for this Hierarchie test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Hierarchie fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(HierarchieTest.class);
	}

	/**
	 * Constructs a new Hierarchie test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HierarchieTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Hierarchie test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Hierarchie fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Hierarchie test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Hierarchie getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(NosqlFactory.eINSTANCE.createHierarchie());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //HierarchieTest
