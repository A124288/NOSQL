/**
 */
package nosql.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import nosql.Fait;
import nosql.NosqlFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Fait</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class FaitTest extends TestCase {

	/**
	 * The fixture for this Fait test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Fait fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(FaitTest.class);
	}

	/**
	 * Constructs a new Fait test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FaitTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Fait test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Fait fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Fait test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Fait getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(NosqlFactory.eINSTANCE.createFait());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //FaitTest
