/**
 */
package nosql.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import nosql.NosqlFactory;
import nosql.WeakAttribute;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Weak Attribute</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class WeakAttributeTest extends TestCase {

	/**
	 * The fixture for this Weak Attribute test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeakAttribute fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(WeakAttributeTest.class);
	}

	/**
	 * Constructs a new Weak Attribute test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeakAttributeTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Weak Attribute test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(WeakAttribute fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Weak Attribute test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WeakAttribute getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(NosqlFactory.eINSTANCE.createWeakAttribute());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //WeakAttributeTest
